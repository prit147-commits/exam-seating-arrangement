# Exam Seating Arrangement Optimization System — Simple Edition
ADIT • Information Technology • DAA • 5th Semester • AY 2026–27

Team: Parth Thanki (12402080601101), Prit Paghadar (12402080601109), Vishal Modhvadiya (12402080601152). Faculty: Yamini Dubey. Group number: [Add assigned group number].

## Run on Windows
Extract ZIP, open PowerShell inside this folder, then:
```powershell
python -m pip install -r requirements.txt
python -m streamlit run app.py
```
Open the local URL Streamlit prints, usually http://localhost:8501.

## Test
```powershell
python -m unittest discover -s tests -v
```

## Workflow
Input students → configure rooms/blocked seats → choose algorithm → generate → independently validate → view/export → compare/benchmark.

## Algorithms
- Greedy: choose the first currently valid seat; no backtracking.
- Backtracking: try seats recursively and undo choices when later placement fails.
- Branch and Bound: minimize same-group diagonal pairs while obeying hard rules. Current score is a valid lower bound because future penalties are non-negative. A state limit means optimality may remain unproven.

Hard rule: same-group students cannot be horizontal/vertical neighbours. Blocked seats cannot be used. Use actual benchmark output in your report; never invent timings. The final seating plan must be reviewed against institutional rules.
