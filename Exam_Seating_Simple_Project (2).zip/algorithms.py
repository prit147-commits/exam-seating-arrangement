from dataclasses import dataclass
from time import perf_counter

@dataclass
class Student:
    student_id: str
    name: str
    group: str

@dataclass
class Room:
    name: str
    rows: int
    cols: int
    blocked: set

@dataclass
class Result:
    algorithm: str
    assignments: dict
    unallocated: list
    runtime: float
    states: int
    status: str
    optimality: str
    score: int = 0

def seats_for(rooms):
    return [(r.name,i,j) for r in rooms for i in range(r.rows) for j in range(r.cols) if (i,j) not in r.blocked]

def conflict(s, seat, assigned, byid):
    room,row,col=seat
    for sid,(rm,r,c) in assigned.items():
        if rm==room and abs(row-r)+abs(col-c)==1 and byid[sid].group==s.group: return True
    return False

def score(assignments, byid):
    pairs=list(assignments.items()); total=0
    for i,(sid,(room,r,c)) in enumerate(pairs):
        for oid,(rm,rr,cc) in pairs[i+1:]:
            if room==rm and abs(r-rr)==1 and abs(c-cc)==1 and byid[sid].group==byid[oid].group: total+=1
    return total

def validate(students, rooms, assignments):
    errors=[]; byid={s.student_id:s for s in students}; roommap={r.name:r for r in rooms}
    if len(byid)!=len(students): errors.append("Duplicate student IDs.")
    seats=list(assignments.values())
    if len(seats)!=len(set(seats)): errors.append("Seat assigned more than once.")
    for sid,(name,row,col) in assignments.items():
        if sid not in byid: errors.append("Unknown student ID."); continue
        if name not in roommap: errors.append("Unknown room."); continue
        room=roommap[name]
        if not (0<=row<room.rows and 0<=col<room.cols): errors.append("Invalid seat.")
        elif (row,col) in room.blocked: errors.append("Blocked seat used.")
    for sid,seat in assignments.items():
        if sid in byid and conflict(byid[sid],seat,{k:v for k,v in assignments.items() if k!=sid},byid):
            errors.append("Same-group orthogonal adjacency.")
    return sorted(set(errors))

def greedy(students, rooms):
    t=perf_counter(); seats=seats_for(rooms); byid={s.student_id:s for s in students}; a={}
    for s in students:
        for seat in seats:
            if seat not in a.values() and not conflict(s,seat,a,byid):
                a[s.student_id]=seat; break
    un=[s.student_id for s in students if s.student_id not in a]
    return Result("Greedy",a,un,perf_counter()-t,len(students)*len(seats),
                  "FEASIBLE_COMPLETE" if not un else "FEASIBLE_PARTIAL","NOT_PROVEN",score(a,byid))

def backtracking(students, rooms, limit=20000):
    t=perf_counter(); seats=seats_for(rooms); byid={s.student_id:s for s in students}
    if len(byid)!=len(students):
        return Result("Backtracking",{},[s.student_id for s in students],perf_counter()-t,0,"INVALID_INPUT","NOT_PROVEN")
    if len(students)>len(seats):
        return Result("Backtracking",{},[s.student_id for s in students],perf_counter()-t,0,"INFEASIBLE_PROVEN","PROVEN_NO_SOLUTION")
    counts={s.group:sum(x.group==s.group for x in students) for s in students}
    order=sorted(students,key=lambda s:(-counts[s.group],s.student_id)); a={}; states=0; found=False; hit=False
    def search(i):
        nonlocal states,found,hit
        if i==len(order): found=True; return True
        for seat in seats:
            if states>=limit: hit=True; return False
            states+=1
            if seat in a.values() or conflict(order[i],seat,a,byid): continue
            a[order[i].student_id]=seat
            if search(i+1): return True
            del a[order[i].student_id]
            if hit:return False
        return False
    search(0)
    if found: status,opt,un="FEASIBLE_COMPLETE","FEASIBLE_NOT_OPTIMALITY_OBJECTIVE",[]
    elif hit: status,opt,un="SEARCH_LIMIT_REACHED","NOT_PROVEN",[s.student_id for s in students]; a={}
    else: status,opt,un="INFEASIBLE_PROVEN","PROVEN_NO_SOLUTION",[s.student_id for s in students]
    return Result("Backtracking",dict(a),un,perf_counter()-t,states,status,opt,score(a,byid))

def branch_and_bound(students, rooms, limit=20000):
    # Minimize same-group diagonal pairs. Current score is a valid lower bound:
    # future assignments can add penalties but can never subtract them.
    t=perf_counter(); seats=seats_for(rooms); byid={s.student_id:s for s in students}
    if len(byid)!=len(students):
        return Result("Branch and Bound",{},[s.student_id for s in students],perf_counter()-t,0,"INVALID_INPUT","NOT_PROVEN")
    if len(students)>len(seats):
        return Result("Branch and Bound",{},[s.student_id for s in students],perf_counter()-t,0,"INFEASIBLE_PROVEN","PROVEN_NO_SOLUTION")
    counts={s.group:sum(x.group==s.group for x in students) for s in students}
    order=sorted(students,key=lambda s:(-counts[s.group],s.student_id))
    cur={}; best=None; bestscore=float("inf"); states=0; hit=False
    def search(i,cost):
        nonlocal best,bestscore,states,hit
        if cost>=bestscore:return
        if i==len(order): best=dict(cur); bestscore=cost; return
        s=order[i]
        for seat in seats:
            if states>=limit: hit=True; return
            states+=1
            if seat in cur.values() or conflict(s,seat,cur,byid):continue
            room,r,c=seat; extra=sum(1 for sid,(rm,rr,cc) in cur.items()
                if room==rm and abs(r-rr)==1 and abs(c-cc)==1 and byid[sid].group==s.group)
            if cost+extra>=bestscore:continue
            cur[s.student_id]=seat; search(i+1,cost+extra); del cur[s.student_id]
            if hit and best is None:return
    search(0,0)
    if best is not None:
        status="SEARCH_LIMIT_FEASIBLE" if hit else "OPTIMAL_PROVEN"
        opt="NOT_PROVEN" if hit else "PROVEN_OPTIMAL"; un=[]; a=best; sc=int(bestscore)
    elif hit: status,opt,un,a,sc="SEARCH_LIMIT_REACHED","NOT_PROVEN",[s.student_id for s in students],{},0
    else: status,opt,un,a,sc="INFEASIBLE_PROVEN","PROVEN_NO_SOLUTION",[s.student_id for s in students],{},0
    return Result("Branch and Bound",a,un,perf_counter()-t,states,status,opt,sc)
