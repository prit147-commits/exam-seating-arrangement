import unittest
from algorithms import Student,Room,greedy,backtracking,branch_and_bound,validate

class Tests(unittest.TestCase):
 def setUp(self):
  self.s=[Student("1","One","A"),Student("2","Two","B"),Student("3","Three","A"),Student("4","Four","B")]
  self.r=[Room("R",2,2,set())]
 def test_backtracking_valid(self):
  x=backtracking(self.s,self.r,1000);self.assertEqual(len(x.assignments),4);self.assertEqual(validate(self.s,self.r,x.assignments),[])
 def test_bnb_proves_small_optimum(self):
  x=branch_and_bound(self.s,self.r,1000);self.assertEqual(x.status,"OPTIMAL_PROVEN");self.assertEqual(validate(self.s,self.r,x.assignments),[])
 def test_greedy_returns_all_records(self):
  x=greedy(self.s,self.r);self.assertEqual(len(x.assignments)+len(x.unallocated),4)
 def test_insufficient_capacity(self):
  s=self.s+[Student("5","Five","C")];self.assertEqual(backtracking(s,self.r).status,"INFEASIBLE_PROVEN")
 def test_blocked_seat(self):
  r=[Room("R",2,2,{(0,0)})];x=backtracking(self.s,r,1000);self.assertEqual(validate(self.s,r,x.assignments),[])
 def test_duplicate_id(self):
  s=[Student("1","One","A"),Student("1","Copy","B")];self.assertEqual(backtracking(s,self.r).status,"INVALID_INPUT")
if __name__=="__main__":unittest.main()
