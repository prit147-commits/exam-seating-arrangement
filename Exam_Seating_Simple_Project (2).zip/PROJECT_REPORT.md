# Exam Seating Arrangement Optimization System
## DAA Mini Project Report — 2026–27
**Institute:** A. D. Patel Institute of Technology (ADIT) | **Department:** Information Technology | **Course:** DAA, 5th Semester | **Faculty:** Yamini Dubey | **Group:** [Add assigned group number]

**Team:** Parth Thanki — 12402080601101; Prit Paghadar — 12402080601109; Vishal Modhvadiya — 12402080601152.

## Abstract
This project models exam seating as a constraint-search problem. It uses Python and Streamlit and implements three distinct approaches: Greedy, Backtracking, and Branch and Bound. The system supports student and room input, blocked seats, validation, classroom grids, CSV import/export, comparisons, and benchmarks. Branch and Bound minimizes same-group diagonal pairs as a soft objective.

## Problem definition
Input: student ID, name, examination group, rooms, row/column dimensions, blocked seat coordinates. Output: student-to-seat mapping, unallocated students, validation findings, runtime and search states. Hard constraints: unique IDs, unique seat occupancy, valid coordinates, no blocked seats, and no same-group horizontal/vertical neighbours. Soft objective: minimize same-group diagonal pairs in Branch and Bound.

## Workflow and architecture
Problem → input → constraints → algorithm → implementation → testing → benchmark → results.
`app.py` is the Streamlit interface. `algorithms.py` contains data models, seat enumeration, constraint checks, validator, and all three algorithms. `tests/` contains unit tests. `data/sample_students.csv` is sample input.

## Algorithm summaries
**Greedy:** For each student, scan seats in fixed order and choose the first unused, non-conflicting seat. If none exists, mark unallocated. It is simple but can fail despite another arrangement existing.

**Backtracking:** Order students by most frequent group first. Try each unused valid seat recursively; undo an assignment when a later student cannot be placed. Exhaustive failure proves infeasibility. A search-limit result does not.

**Branch and Bound:** Search valid complete arrangements while minimizing the number of same-group diagonal pairs. The current score is a valid lower bound because adding students can only keep or increase the penalty. Once a complete incumbent exists, a branch with lower bound at least the incumbent cannot improve it and may be pruned. If the state limit is reached, optimality is not claimed.

## Pseudocode
Greedy: initialize empty assignment; for each student scan seats; take first valid unused seat; otherwise mark unallocated; return result.
Backtracking: if all students placed, succeed; for each seat, count state; skip used/conflicting seats; assign and recurse; undo on failure; return solution/proof/limit status.
Branch and Bound: maintain partial assignment and incumbent; calculate current penalty lower bound; prune if bound ≥ incumbent; branch on valid unused seats; add newly created diagonal penalty; record better complete plan; report optimality only if search ends without limit.

## Complexity
Let n be students and m be usable seats. In this implementation, checking a candidate can scan up to O(n) assignments. Greedy has a conservative upper bound O(n²m). Backtracking and Branch and Bound have exponential worst-case search in the number of seat choices, with O(n) recursion/assignment state (excluding input and candidate-seat list). B&B's depth-first implementation has O(n) search stack; bound/pruning checks add overhead. A single universal average-case bound is not meaningful without an input distribution. These are code-based bounds; discuss assumptions in the viva.

## Testing
Run `python -m unittest discover -s tests -v`. Tests cover a feasible arrangement, B&B small optimum, Greedy result accounting, insufficient capacity, blocked seats, and duplicate IDs. Record the actual output on the submission computer.

## Performance evaluation
Use the app's Performance Analysis page with 10, 50, 100, and 500 students where practical. Export the actual CSV. Report runtime, allocated/unallocated counts, search states, status and score. The exact algorithms can reach their search limits; do not report a limit as infeasibility. Do not invent timing results.

## Limitations and future scope
Exact search may grow exponentially; Greedy is not guaranteed to find a complete solution; modeled constraints may differ from institutional policy. Future improvements include richer conflict rules, editing records, persistent storage, and stronger optimization bounds.

## Conclusion
The project compares three distinct approaches to a practical constraint problem and includes independent validation, automated tests, and reproducible benchmarks. Conclusions should be based on actual test and benchmark output.

## References
ADIT DAA Mini Project Rules & Guidelines; ADIT DAA Mini Project Problem Statements; ADIT DAA Mini Project Presentation Format; Python documentation (https://docs.python.org/3/); Streamlit documentation (https://docs.streamlit.io/); Matplotlib documentation (https://matplotlib.org/stable/).
