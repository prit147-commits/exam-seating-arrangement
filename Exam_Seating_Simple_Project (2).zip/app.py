import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
from algorithms import Student,Room,greedy,backtracking,branch_and_bound,validate,seats_for

st.set_page_config(page_title="Exam Seating Optimizer",page_icon="🪑",layout="wide")
st.title("Exam Seating Arrangement Optimization System")
st.caption("ADIT • Information Technology • DAA Mini Project • 2026–27")
if "students" not in st.session_state:
    st.session_state.students=[Student(f"S{i:03}",f"Student {i}",f"PAPER-{(i-1)%3+1}") for i in range(1,11)]
if "rooms" not in st.session_state: st.session_state.rooms=[Room("Room 101",4,4,set())]
if "result" not in st.session_state: st.session_state.result=None
pages=["Dashboard","Student Management","Classroom Configuration","Seating Constraints","Generate Seating Arrangement","Classroom Seating View","Algorithm Comparison","Performance Analysis","Help & Algorithm Explanation"]
page=st.sidebar.radio("Navigate",pages)
students,rooms=st.session_state.students,st.session_state.rooms
def student_df(): return pd.DataFrame([{"student_id":s.student_id,"name":s.name,"exam_group":s.group} for s in students])
def room_df(): return pd.DataFrame([{"Room":r.name,"Rows":r.rows,"Columns":r.cols,"Capacity":r.rows*r.cols,"Blocked":len(r.blocked),"Usable":r.rows*r.cols-len(r.blocked)} for r in rooms])
def run(name,limit=3000):
    if name=="Greedy":return greedy(students,rooms)
    if name=="Backtracking":return backtracking(students,rooms,limit)
    return branch_and_bound(students,rooms,limit)

if page=="Dashboard":
    r=st.session_state.result
    a,b,c,d=st.columns(4); a.metric("Students",len(students)); b.metric("Exam groups",len(set(s.group for s in students))); c.metric("Classrooms",len(rooms)); d.metric("Usable seats",len(seats_for(rooms)))
    if r:
        a,b,c,d=st.columns(4); a.metric("Allocated",len(r.assignments)); b.metric("Unallocated",len(r.unallocated)); c.metric("Search states",r.states); d.metric("Runtime",f"{r.runtime:.6f}s")
        st.write("Algorithm:",r.algorithm,"| Status:",r.status,"| Optimality:",r.optimality)
    st.subheader("Students"); st.dataframe(student_df(),use_container_width=True,hide_index=True)
    st.subheader("Classrooms"); st.dataframe(room_df(),use_container_width=True,hide_index=True)
elif page=="Student Management":
    with st.form("add",clear_on_submit=True):
        sid=st.text_input("Student ID"); name=st.text_input("Name"); group=st.text_input("Exam group")
        if st.form_submit_button("Add student"):
            if not sid.strip() or not name.strip() or not group.strip():st.error("All fields are required.")
            elif any(s.student_id==sid.strip() for s in students):st.error("Duplicate ID.")
            else:students.append(Student(sid.strip(),name.strip(),group.strip()));st.session_state.result=None;st.rerun()
    up=st.file_uploader("Import CSV: student_id,name,exam_group",type=["csv"])
    if up and st.button("Import CSV"):
        try:
            df=pd.read_csv(up)
            if not {"student_id","name","exam_group"}.issubset(df.columns) or df.isna().any().any():raise ValueError("CSV needs non-empty student_id,name,exam_group columns.")
            incoming=[Student(str(x.student_id),str(x.name),str(x.exam_group)) for x in df.itertuples()]
            ids=[s.student_id for s in incoming]
            if len(ids)!=len(set(ids)) or set(ids)&{s.student_id for s in students}:raise ValueError("Duplicate student ID.")
            students.extend(incoming);st.session_state.result=None;st.rerun()
        except Exception as e:st.error(str(e))
    st.dataframe(student_df(),use_container_width=True,hide_index=True)
    sid=st.selectbox("Delete student",[""]+[s.student_id for s in students])
    if st.button("Delete selected",disabled=not sid):st.session_state.students=[s for s in students if s.student_id!=sid];st.session_state.result=None;st.rerun()
    st.download_button("Export students CSV",student_df().to_csv(index=False).encode(),"students.csv","text/csv")
elif page=="Classroom Configuration":
    with st.form("room",clear_on_submit=True):
        name=st.text_input("Room name"); rows=st.number_input("Rows",1,50,4); cols=st.number_input("Columns",1,50,4)
        if st.form_submit_button("Add room"):
            if not name.strip() or any(r.name==name.strip() for r in rooms):st.error("Enter a unique room name.")
            else:rooms.append(Room(name.strip(),int(rows),int(cols),set()));st.session_state.result=None;st.rerun()
    st.dataframe(room_df(),use_container_width=True,hide_index=True)
    if rooms:
        rn=st.selectbox("Select room for blocked seats",[r.name for r in rooms]); room=next(r for r in rooms if r.name==rn)
        txt=st.text_input("Blocked coordinates (row,col; e.g. 1,2;2,3)",value=";".join(f"{r+1},{c+1}" for r,c in sorted(room.blocked)))
        if st.button("Save blocked seats"):
            try:
                blocked=set()
                for token in txt.split(";"):
                    if token.strip():
                        r,c=map(int,token.split(","))
                        if not(1<=r<=room.rows and 1<=c<=room.cols):raise ValueError("Coordinate outside room.")
                        blocked.add((r-1,c-1))
                room.blocked=blocked;st.session_state.result=None;st.rerun()
            except Exception as e:st.error(str(e))
elif page=="Seating Constraints":
    st.write("Hard rule: same-group students cannot be immediate horizontal/vertical neighbours.")
    st.write("Other hard rules: unique student IDs, one student per seat, valid coordinates, no blocked seats.")
    st.write("Branch and Bound soft objective: minimize same-group diagonal pairs.")
    st.metric("Usable seats",len(seats_for(rooms)));st.metric("Students",len(students))
    if len(students)>len(seats_for(rooms)):st.error("Insufficient capacity.")
    else:st.success("Total capacity is sufficient; group constraints may still prevent a full arrangement.")
elif page=="Generate Seating Arrangement":
    algo=st.selectbox("Algorithm",["Greedy","Backtracking","Branch and Bound"]);limit=st.number_input("Search-state limit",100,100000,3000,100)
    if st.button("Generate arrangement",type="primary"):
        if not students or not rooms:st.error("Add students and at least one room.")
        else:st.session_state.result=run(algo,int(limit));st.session_state.selected=algo
    r=st.session_state.result
    if r:
        a,b,c,d=st.columns(4);a.metric("Allocated",len(r.assignments));b.metric("Unallocated",len(r.unallocated));c.metric("States",r.states);d.metric("Runtime",f"{r.runtime:.6f}s")
        st.write("Status:",r.status,"| Optimality:",r.optimality,"| Diagonal penalty:",r.score)
        errors=validate(students,rooms,r.assignments)
        if errors:st.error("\n".join(errors))
        elif not r.unallocated:st.success("Independent validator: no hard-constraint errors.")
        else:st.warning("Partial result or search limit; review unallocated students.")
        byid={s.student_id:s for s in students}
        data=[{"Student ID":sid,"Name":byid[sid].name,"Group":byid[sid].group,"Room":seat[0],"Row":seat[1]+1,"Column":seat[2]+1} for sid,seat in r.assignments.items()]
        st.dataframe(pd.DataFrame(data),use_container_width=True,hide_index=True)
        st.download_button("Export seating CSV",pd.DataFrame(data).to_csv(index=False).encode(),"seating.csv","text/csv")
        st.write("Unallocated:",", ".join(r.unallocated) if r.unallocated else "None")
elif page=="Classroom Seating View":
    r=st.session_state.result
    if not r:st.info("Generate a seating arrangement first.")
    elif not rooms:st.warning("No rooms configured.")
    else:
        rn=st.selectbox("Room",[x.name for x in rooms]);room=next(x for x in rooms if x.name==rn);occupant={seat:sid for sid,seat in r.assignments.items()};byid={s.student_id:s for s in students};grid=[]
        for i in range(room.rows):
            line=[]
            for j in range(room.cols):
                if (i,j) in room.blocked:label="BLOCKED"
                else:
                    sid=occupant.get((room.name,i,j));label=f"{sid}\n{byid[sid].group}" if sid else "EMPTY"
                line.append(label)
            grid.append(line)
        st.dataframe(pd.DataFrame(grid,index=[f"Row {i+1}" for i in range(room.rows)],columns=[f"Col {i+1}" for i in range(room.cols)]),use_container_width=True)
        st.caption("Legend: student ID=occupied; EMPTY=available; BLOCKED=unavailable.")
elif page=="Algorithm Comparison":
    limit=st.number_input("State limit for exact algorithms",100,100000,2000,100)
    if st.button("Compare all three"):
        results=[run(n,int(limit)) for n in ["Greedy","Backtracking","Branch and Bound"]]
        st.session_state.comparison=pd.DataFrame([{"Algorithm":r.algorithm,"Runtime (s)":r.runtime,"Allocated":len(r.assignments),"Unallocated":len(r.unallocated),"Violations":len(validate(students,rooms,r.assignments)),"States":r.states,"Status":r.status,"Optimality":r.optimality,"Score":r.score} for r in results])
    if "comparison" in st.session_state:
        st.dataframe(st.session_state.comparison,use_container_width=True,hide_index=True)
        fig,ax=plt.subplots();ax.bar(st.session_state.comparison["Algorithm"],st.session_state.comparison["Runtime (s)"]);ax.set_ylabel("Seconds");ax.set_title("Runtime on identical input");plt.xticks(rotation=15);st.pyplot(fig);plt.close(fig)
elif page=="Performance Analysis":
    sizes=st.multiselect("Synthetic student counts",[10,50,100,500],default=[10,50]);limit=st.number_input("State limit",100,100000,1000,100)
    if st.button("Run benchmarks"):
        rows=[]
        for n in sizes:
            sample=[Student(f"S{i:04}",f"Student {i}",f"G{(i-1)%4+1}") for i in range(1,n+1)]
            testrooms=[Room(f"Room {i+1}",10,10,set()) for i in range((n+99)//100)]
            old_s,old_r=st.session_state.students,st.session_state.rooms
            st.session_state.students,st.session_state.rooms=sample,testrooms
            for name in ["Greedy","Backtracking","Branch and Bound"]:
                r=run(name,int(limit));rows.append({"Students":n,"Algorithm":name,"Runtime (s)":r.runtime,"Allocated":len(r.assignments),"Unallocated":len(r.unallocated),"States":r.states,"Status":r.status,"Optimality":r.optimality,"Score":r.score})
            st.session_state.students,st.session_state.rooms=old_s,old_r
        st.session_state.bench=pd.DataFrame(rows)
    if "bench" in st.session_state:
        st.dataframe(st.session_state.bench,use_container_width=True,hide_index=True)
        fig,ax=plt.subplots()
        for name,part in st.session_state.bench.groupby("Algorithm"):ax.plot(part["Students"],part["Runtime (s)"],marker="o",label=name)
        ax.set_xlabel("Students");ax.set_ylabel("Seconds");ax.legend();ax.grid(True,alpha=.3);st.pyplot(fig);plt.close(fig)
        st.download_button("Download benchmark CSV",st.session_state.bench.to_csv(index=False).encode(),"benchmark.csv","text/csv")
else:
    st.subheader("How it works")
    st.markdown("""**Greedy:** choose the first valid seat; no undo/backtracking.\n\n**Backtracking:** try a seat, recursively place the next student, and undo when stuck.\n\n**Branch and Bound:** minimize same-group diagonal pairs. Current score is a valid lower bound because future penalties cannot be negative; prune branches whose lower bound is at least the best score.\n\n**Workflow:** input → configure rooms → choose algorithm → generate → validate → view/export → compare/benchmark.\n\nA search limit is not proof of infeasibility.""")
    st.write("Parth Thanki — 12402080601101");st.write("Prit Paghadar — 12402080601109");st.write("Vishal Modhvadiya — 12402080601152");st.write("Faculty: Yamini Dubey");st.write("Group number: [Add assigned group number]")
