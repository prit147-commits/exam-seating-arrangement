# Requirement checklist
| Requirement from official brief | Where addressed | Verification |
|---|---|---|
| Exact topic and team details | README, report, app | Check names and IDs; group remains placeholder |
| Python, Streamlit, CSV, Matplotlib | app.py, requirements.txt | Install and run |
| Three distinct algorithms | algorithms.py | Review and run tests |
| Student add/delete/list/CSV import/export | Student Management | Demonstrate |
| Multiple rooms and blocked seats | Classroom Configuration | Demonstrate |
| Hard constraints and independent validation | algorithms.py + Generate page | Run tests and inspect output |
| Nine required pages | app.py navigation | Click each page |
| Algorithm comparison and benchmarks | app.py | Run and save actual CSV |
| Pseudocode and complexity analysis | PROJECT_REPORT.md | Verify against code |
| Actual screenshots | Capture from running application | Pending until captured |
| 12–15 slide presentation | Must be prepared from official template | Pending |
| Actual performance results | Performance page output | Pending until run |
